setInterval(function() {
var link = document.getElementById('prix');
var valeur =link.value;
document.getElementById('prixDiv').innerHTML = valeur;},200);

